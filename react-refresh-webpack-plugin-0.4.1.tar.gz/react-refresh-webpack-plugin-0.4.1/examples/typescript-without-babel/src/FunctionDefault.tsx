import * as React from 'react';

function FunctionDefault() {
  return <h1>Default Export Function</h1>;
}

export default FunctionDefault;
