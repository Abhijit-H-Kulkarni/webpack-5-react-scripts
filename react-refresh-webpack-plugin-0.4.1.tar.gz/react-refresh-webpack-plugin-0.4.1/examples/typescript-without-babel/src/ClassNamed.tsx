import * as React from 'react';

export class ClassNamed extends React.Component {
  render() {
    return <h1>Named Export Class</h1>;
  }
}
