// @flow

import * as React from 'react';

export function FunctionNamed() {
  return <h1>Named Export Function</h1>;
}
