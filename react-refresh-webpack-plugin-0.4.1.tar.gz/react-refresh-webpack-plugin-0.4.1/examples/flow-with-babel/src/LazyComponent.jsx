// @flow

import * as React from 'react';

function LazyComponent() {
  return <h1>Lazy Component</h1>;
}

export default LazyComponent;
