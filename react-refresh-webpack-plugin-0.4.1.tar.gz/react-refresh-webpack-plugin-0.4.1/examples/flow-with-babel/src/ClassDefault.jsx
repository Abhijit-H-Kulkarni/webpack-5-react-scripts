// @flow

import * as React from 'react';

class ClassDefault extends React.Component<{}> {
  render() {
    return <h1>Default Export Class</h1>;
  }
}

export default ClassDefault;
